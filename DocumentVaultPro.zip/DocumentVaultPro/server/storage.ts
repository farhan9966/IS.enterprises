import {
  users,
  documentCategories,
  vehicles,
  employees,
  documents,
  documentDownloads,
  type User,
  type UpsertUser,
  type DocumentCategory,
  type InsertDocumentCategory,
  type Vehicle,
  type InsertVehicle,
  type Employee,
  type InsertEmployee,
  type Document,
  type InsertDocument,
  type DocumentDownload,
  type InsertDocumentDownload,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, asc, ilike, or, sql, gte, lte } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;

  // Document category operations
  getDocumentCategories(): Promise<DocumentCategory[]>;
  createDocumentCategory(category: InsertDocumentCategory): Promise<DocumentCategory>;
  getDocumentCategoriesByParent(parentId?: number): Promise<DocumentCategory[]>;

  // Vehicle operations
  getVehicles(): Promise<Vehicle[]>;
  getVehicle(id: number): Promise<Vehicle | undefined>;
  createVehicle(vehicle: InsertVehicle): Promise<Vehicle>;
  updateVehicle(id: number, vehicle: Partial<InsertVehicle>): Promise<Vehicle>;
  deleteVehicle(id: number): Promise<void>;

  // Employee operations
  getEmployees(): Promise<Employee[]>;
  getEmployee(id: number): Promise<Employee | undefined>;
  createEmployee(employee: InsertEmployee): Promise<Employee>;
  updateEmployee(id: number, employee: Partial<InsertEmployee>): Promise<Employee>;
  deleteEmployee(id: number): Promise<void>;

  // Document operations
  getDocuments(entityType?: string, entityId?: number): Promise<Document[]>;
  getDocument(id: number): Promise<Document | undefined>;
  createDocument(document: InsertDocument): Promise<Document>;
  updateDocument(id: number, document: Partial<InsertDocument>): Promise<Document>;
  deleteDocument(id: number): Promise<void>;
  searchDocuments(query: string): Promise<Document[]>;
  getExpiringDocuments(days: number): Promise<Document[]>;
  getRecentDocuments(limit: number): Promise<Document[]>;
  getDocumentsByCategory(categoryId: number): Promise<Document[]>;

  // Document download tracking
  logDocumentDownload(download: InsertDocumentDownload): Promise<DocumentDownload>;
  getRecentDownloads(userId: string, limit: number): Promise<DocumentDownload[]>;
  getDocumentDownloadStats(documentId: number): Promise<{ count: number }>;

  // Dashboard stats
  getDashboardStats(): Promise<{
    totalDocuments: number;
    expiringSoon: number;
    activeVehicles: number;
    activeEmployees: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Document category operations
  async getDocumentCategories(): Promise<DocumentCategory[]> {
    return await db.select().from(documentCategories).orderBy(asc(documentCategories.name));
  }

  async createDocumentCategory(category: InsertDocumentCategory): Promise<DocumentCategory> {
    const [newCategory] = await db
      .insert(documentCategories)
      .values(category)
      .returning();
    return newCategory;
  }

  async getDocumentCategoriesByParent(parentId?: number): Promise<DocumentCategory[]> {
    if (parentId === undefined) {
      return await db
        .select()
        .from(documentCategories)
        .where(sql`${documentCategories.parentId} IS NULL`)
        .orderBy(asc(documentCategories.name));
    }
    return await db
      .select()
      .from(documentCategories)
      .where(eq(documentCategories.parentId, parentId))
      .orderBy(asc(documentCategories.name));
  }

  // Vehicle operations
  async getVehicles(): Promise<Vehicle[]> {
    return await db
      .select()
      .from(vehicles)
      .orderBy(desc(vehicles.createdAt));
  }

  async getVehicle(id: number): Promise<Vehicle | undefined> {
    const [vehicle] = await db
      .select()
      .from(vehicles)
      .where(eq(vehicles.id, id));
    return vehicle;
  }

  async createVehicle(vehicle: InsertVehicle): Promise<Vehicle> {
    const [newVehicle] = await db
      .insert(vehicles)
      .values(vehicle)
      .returning();
    return newVehicle;
  }

  async updateVehicle(id: number, vehicle: Partial<InsertVehicle>): Promise<Vehicle> {
    const [updatedVehicle] = await db
      .update(vehicles)
      .set({ ...vehicle, updatedAt: new Date() })
      .where(eq(vehicles.id, id))
      .returning();
    return updatedVehicle;
  }

  async deleteVehicle(id: number): Promise<void> {
    await db.delete(vehicles).where(eq(vehicles.id, id));
  }

  // Employee operations
  async getEmployees(): Promise<Employee[]> {
    return await db
      .select()
      .from(employees)
      .orderBy(desc(employees.createdAt));
  }

  async getEmployee(id: number): Promise<Employee | undefined> {
    const [employee] = await db
      .select()
      .from(employees)
      .where(eq(employees.id, id));
    return employee;
  }

  async createEmployee(employee: InsertEmployee): Promise<Employee> {
    const [newEmployee] = await db
      .insert(employees)
      .values(employee)
      .returning();
    return newEmployee;
  }

  async updateEmployee(id: number, employee: Partial<InsertEmployee>): Promise<Employee> {
    const [updatedEmployee] = await db
      .update(employees)
      .set({ ...employee, updatedAt: new Date() })
      .where(eq(employees.id, id))
      .returning();
    return updatedEmployee;
  }

  async deleteEmployee(id: number): Promise<void> {
    await db.delete(employees).where(eq(employees.id, id));
  }

  // Document operations
  async getDocuments(entityType?: string, entityId?: number): Promise<Document[]> {
    const baseCondition = eq(documents.isActive, true);
    
    if (entityType && entityId) {
      return await db
        .select()
        .from(documents)
        .where(
          and(
            baseCondition,
            eq(documents.entityType, entityType),
            eq(documents.entityId, entityId)
          )
        )
        .orderBy(desc(documents.createdAt));
    } else if (entityType) {
      return await db
        .select()
        .from(documents)
        .where(
          and(
            baseCondition,
            eq(documents.entityType, entityType)
          )
        )
        .orderBy(desc(documents.createdAt));
    }
    
    return await db
      .select()
      .from(documents)
      .where(baseCondition)
      .orderBy(desc(documents.createdAt));
  }

  async getDocument(id: number): Promise<Document | undefined> {
    const [document] = await db
      .select()
      .from(documents)
      .where(and(eq(documents.id, id), eq(documents.isActive, true)));
    return document;
  }

  async createDocument(document: InsertDocument): Promise<Document> {
    const [newDocument] = await db
      .insert(documents)
      .values(document)
      .returning();
    return newDocument;
  }

  async updateDocument(id: number, document: Partial<InsertDocument>): Promise<Document> {
    const [updatedDocument] = await db
      .update(documents)
      .set({ ...document, updatedAt: new Date() })
      .where(eq(documents.id, id))
      .returning();
    return updatedDocument;
  }

  async deleteDocument(id: number): Promise<void> {
    await db
      .update(documents)
      .set({ isActive: false, updatedAt: new Date() })
      .where(eq(documents.id, id));
  }

  async searchDocuments(query: string): Promise<Document[]> {
    return await db
      .select()
      .from(documents)
      .where(
        and(
          eq(documents.isActive, true),
          or(
            ilike(documents.title, `%${query}%`),
            ilike(documents.description, `%${query}%`),
            ilike(documents.fileName, `%${query}%`)
          )
        )
      )
      .orderBy(desc(documents.createdAt));
  }

  async getExpiringDocuments(days: number): Promise<Document[]> {
    const futureDate = new Date();
    futureDate.setDate(futureDate.getDate() + days);
    
    return await db
      .select()
      .from(documents)
      .where(
        and(
          eq(documents.isActive, true),
          sql`${documents.expirationDate} IS NOT NULL`,
          lte(documents.expirationDate, futureDate.toISOString().split('T')[0])
        )
      )
      .orderBy(asc(documents.expirationDate));
  }

  async getRecentDocuments(limit: number): Promise<Document[]> {
    return await db
      .select()
      .from(documents)
      .where(eq(documents.isActive, true))
      .orderBy(desc(documents.createdAt))
      .limit(limit);
  }

  async getDocumentsByCategory(categoryId: number): Promise<Document[]> {
    return await db
      .select()
      .from(documents)
      .where(
        and(
          eq(documents.isActive, true),
          eq(documents.categoryId, categoryId)
        )
      )
      .orderBy(desc(documents.createdAt));
  }

  // Document download tracking
  async logDocumentDownload(download: InsertDocumentDownload): Promise<DocumentDownload> {
    const [newDownload] = await db
      .insert(documentDownloads)
      .values(download)
      .returning();
    return newDownload;
  }

  async getRecentDownloads(userId: string, limit: number): Promise<DocumentDownload[]> {
    return await db
      .select()
      .from(documentDownloads)
      .where(eq(documentDownloads.userId, userId))
      .orderBy(desc(documentDownloads.downloadedAt))
      .limit(limit);
  }

  async getDocumentDownloadStats(documentId: number): Promise<{ count: number }> {
    const [result] = await db
      .select({ count: sql`COUNT(*)`.mapWith(Number) })
      .from(documentDownloads)
      .where(eq(documentDownloads.documentId, documentId));
    return result;
  }

  // Dashboard stats
  async getDashboardStats(): Promise<{
    totalDocuments: number;
    expiringSoon: number;
    activeVehicles: number;
    activeEmployees: number;
  }> {
    const [totalDocsResult] = await db
      .select({ count: sql`COUNT(*)`.mapWith(Number) })
      .from(documents)
      .where(eq(documents.isActive, true));

    const futureDate = new Date();
    futureDate.setDate(futureDate.getDate() + 30);
    
    const [expiringSoonResult] = await db
      .select({ count: sql`COUNT(*)`.mapWith(Number) })
      .from(documents)
      .where(
        and(
          eq(documents.isActive, true),
          sql`${documents.expirationDate} IS NOT NULL`,
          lte(documents.expirationDate, futureDate.toISOString().split('T')[0])
        )
      );

    const [activeVehiclesResult] = await db
      .select({ count: sql`COUNT(*)`.mapWith(Number) })
      .from(vehicles)
      .where(eq(vehicles.status, 'active'));

    const [activeEmployeesResult] = await db
      .select({ count: sql`COUNT(*)`.mapWith(Number) })
      .from(employees)
      .where(eq(employees.status, 'active'));

    return {
      totalDocuments: totalDocsResult.count,
      expiringSoon: expiringSoonResult.count,
      activeVehicles: activeVehiclesResult.count,
      activeEmployees: activeEmployeesResult.count,
    };
  }
}

export const storage = new DatabaseStorage();
