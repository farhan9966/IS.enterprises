import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, Calendar, Download } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";

export default function ExpiringDocuments() {
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: expiringDocs, isLoading } = useQuery({
    queryKey: ["/api/dashboard/expiring-documents"],
    enabled: isAuthenticated,
  });

  const downloadMutation = useMutation({
    mutationFn: async (documentId: number) => {
      const response = await fetch(`/api/documents/${documentId}/download`, {
        credentials: "include",
      });

      if (!response.ok) {
        const text = await response.text();
        throw new Error(`${response.status}: ${text}`);
      }

      // Get filename from content-disposition header or use default
      const contentDisposition = response.headers.get('content-disposition');
      let filename = 'document';
      if (contentDisposition) {
        const filenameMatch = contentDisposition.match(/filename="?(.+)"?/);
        if (filenameMatch) {
          filename = filenameMatch[1];
        }
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    },
    onSuccess: () => {
      toast({
        title: "Download Started",
        description: "Document download has started",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/recent-downloads"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Download Failed",
        description: "Failed to download document",
        variant: "destructive",
      });
    },
  });

  const getDaysUntilExpiry = (expirationDate: string) => {
    const expiry = new Date(expirationDate);
    const now = new Date();
    const diffTime = expiry.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const getExpiryBadgeVariant = (days: number) => {
    if (days < 0) return "destructive";
    if (days <= 3) return "destructive";
    if (days <= 7) return "default"; // Using default for warning style
    return "secondary";
  };

  const getExpiryBadgeClass = (days: number) => {
    if (days <= 7 && days > 3) return "bg-warning text-warning-foreground";
    return "";
  };

  const getExpiryText = (days: number) => {
    if (days < 0) return `Expired ${Math.abs(days)} days ago`;
    if (days === 0) return "Expires today";
    if (days === 1) return "Expires tomorrow";
    return `Expires in ${days} days`;
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <AlertTriangle className="h-5 w-5 mr-2 text-warning" />
            Expiring Soon
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="animate-pulse">
                <div className="h-4 bg-slate-200 rounded w-3/4 mb-2"></div>
                <div className="h-3 bg-slate-100 rounded w-1/2"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <AlertTriangle className="h-5 w-5 mr-2 text-warning" />
          Expiring Soon
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {expiringDocs?.length ? (
            expiringDocs.slice(0, 5).map((doc: any) => {
              const daysUntilExpiry = getDaysUntilExpiry(doc.expirationDate);
              return (
                <div 
                  key={doc.id} 
                  className={`flex items-center justify-between p-3 rounded-lg ${
                    daysUntilExpiry < 0 
                      ? "bg-red-50 border border-red-200" 
                      : daysUntilExpiry <= 3 
                      ? "bg-red-50 border border-red-200"
                      : daysUntilExpiry <= 7
                      ? "bg-orange-50 border border-orange-200"
                      : "bg-yellow-50 border border-yellow-200"
                  }`}
                >
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-slate-900 truncate">
                      {doc.title}
                    </p>
                    <div className="flex items-center space-x-2 mt-1">
                      <Calendar className="h-3 w-3 text-slate-500" />
                      <p className="text-xs text-slate-500">
                        {getExpiryText(daysUntilExpiry)}
                      </p>
                    </div>
                    <p className="text-xs text-slate-400 capitalize">
                      {doc.entityType}
                      {doc.entityId && ` #${doc.entityId}`}
                    </p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge 
                      variant={getExpiryBadgeVariant(daysUntilExpiry)}
                      className={`text-xs ${getExpiryBadgeClass(daysUntilExpiry)}`}
                    >
                      {daysUntilExpiry < 0 ? "Expired" : `${daysUntilExpiry}d`}
                    </Badge>
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => downloadMutation.mutate(doc.id)}
                      disabled={downloadMutation.isPending}
                      className="h-8 w-8 p-0"
                    >
                      {downloadMutation.isPending ? (
                        <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-slate-600"></div>
                      ) : (
                        <Download className="h-3 w-3" />
                      )}
                    </Button>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="text-center py-6">
              <AlertTriangle className="h-8 w-8 text-slate-400 mx-auto mb-2" />
              <p className="text-sm text-slate-500">No expiring documents</p>
              <p className="text-xs text-slate-400">All documents are up to date</p>
            </div>
          )}
        </div>
        
        {expiringDocs?.length > 5 && (
          <Button variant="link" size="sm" className="w-full mt-4 text-primary hover:text-blue-700">
            View All Expiring Documents ({expiringDocs.length})
          </Button>
        )}
      </CardContent>
    </Card>
  );
}
