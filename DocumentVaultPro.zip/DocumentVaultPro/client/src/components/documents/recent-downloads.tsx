import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Download, FileText, Clock } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";

export default function RecentDownloads() {
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: recentDownloads, isLoading } = useQuery({
    queryKey: ["/api/dashboard/recent-downloads"],
    enabled: isAuthenticated,
  });

  const downloadMutation = useMutation({
    mutationFn: async (documentId: number) => {
      const response = await fetch(`/api/documents/${documentId}/download`, {
        credentials: "include",
      });

      if (!response.ok) {
        const text = await response.text();
        throw new Error(`${response.status}: ${text}`);
      }

      // Get filename from content-disposition header or use default
      const contentDisposition = response.headers.get('content-disposition');
      let filename = 'document';
      if (contentDisposition) {
        const filenameMatch = contentDisposition.match(/filename="?(.+)"?/);
        if (filenameMatch) {
          filename = filenameMatch[1];
        }
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    },
    onSuccess: () => {
      toast({
        title: "Download Started",
        description: "Document download has started",
      });
      // Refresh the downloads list
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/recent-downloads"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Download Failed",
        description: "Failed to download document",
        variant: "destructive",
      });
    },
  });

  const getFileIcon = (mimeType?: string) => {
    if (mimeType?.includes('pdf')) {
      return <FileText className="h-4 w-4 text-red-600" />;
    }
    if (mimeType?.includes('image')) {
      return <FileText className="h-4 w-4 text-green-600" />;
    }
    return <FileText className="h-4 w-4 text-slate-600" />;
  };

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffDays = Math.floor(diffHours / 24);

    if (diffDays > 0) {
      return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
    } else if (diffHours > 0) {
      return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
    } else {
      const diffMinutes = Math.floor(diffMs / (1000 * 60));
      if (diffMinutes > 0) {
        return `${diffMinutes} minute${diffMinutes > 1 ? 's' : ''} ago`;
      }
      return 'Just now';
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Clock className="h-5 w-5 mr-2 text-primary" />
            Recent Downloads
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="animate-pulse flex items-center space-x-3">
                <div className="w-8 h-8 bg-slate-200 rounded"></div>
                <div className="flex-1">
                  <div className="h-4 bg-slate-200 rounded w-3/4 mb-1"></div>
                  <div className="h-3 bg-slate-100 rounded w-1/2"></div>
                </div>
                <div className="w-6 h-6 bg-slate-200 rounded"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Clock className="h-5 w-5 mr-2 text-primary" />
          Recent Downloads
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {recentDownloads?.length ? (
            recentDownloads.slice(0, 5).map((download: any) => (
              <div key={download.id} className="flex items-center space-x-3 group hover:bg-slate-50 rounded-lg p-2 -m-2 transition-colors">
                <div className="w-8 h-8 bg-slate-100 rounded flex items-center justify-center flex-shrink-0">
                  {getFileIcon(download.document?.mimeType)}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-slate-900 truncate">
                    {download.document?.fileName || download.document?.title || 'Unknown Document'}
                  </p>
                  <div className="flex items-center space-x-2">
                    <p className="text-xs text-slate-500">
                      Downloaded {formatTimeAgo(download.downloadedAt)}
                    </p>
                    {download.document?.mimeType && (
                      <Badge variant="outline" className="text-xs">
                        {download.document.mimeType.split('/')[1]?.toUpperCase()}
                      </Badge>
                    )}
                  </div>
                </div>
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => downloadMutation.mutate(download.documentId)}
                  disabled={downloadMutation.isPending}
                  className="opacity-0 group-hover:opacity-100 transition-opacity h-8 w-8 p-0"
                >
                  {downloadMutation.isPending ? (
                    <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-primary"></div>
                  ) : (
                    <Download className="h-3 w-3" />
                  )}
                </Button>
              </div>
            ))
          ) : (
            <div className="text-center py-6">
              <Download className="h-8 w-8 text-slate-400 mx-auto mb-2" />
              <p className="text-sm text-slate-500">No recent downloads</p>
              <p className="text-xs text-slate-400">Your download history will appear here</p>
            </div>
          )}
        </div>
        
        {recentDownloads?.length > 5 && (
          <Button variant="link" size="sm" className="w-full mt-4 text-primary hover:text-blue-700">
            View All Downloads
          </Button>
        )}
      </CardContent>
    </Card>
  );
}
