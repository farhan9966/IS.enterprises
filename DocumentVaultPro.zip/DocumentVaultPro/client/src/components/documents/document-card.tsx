import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Download, FileText, Calendar, User } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";

interface DocumentCardProps {
  document: {
    id: number;
    title: string;
    description?: string;
    fileName: string;
    fileSize: number;
    mimeType: string;
    entityType: string;
    entityId?: number;
    expirationDate?: string;
    createdAt: string;
    updatedAt: string;
  };
  showEntity?: boolean;
  compact?: boolean;
}

export default function DocumentCard({ document, showEntity = true, compact = false }: DocumentCardProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const downloadMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch(`/api/documents/${document.id}/download`, {
        credentials: "include",
      });

      if (!response.ok) {
        const text = await response.text();
        throw new Error(`${response.status}: ${text}`);
      }

      // Create blob and download
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = document.fileName;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    },
    onSuccess: () => {
      toast({
        title: "Download Started",
        description: `${document.fileName} download has started`,
      });
      // Invalidate download history
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/recent-downloads"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Download Failed",
        description: "Failed to download document",
        variant: "destructive",
      });
    },
  });

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getFileIcon = () => {
    if (document.mimeType.includes('pdf')) {
      return <FileText className="h-4 w-4 text-red-600" />;
    }
    if (document.mimeType.includes('image')) {
      return <FileText className="h-4 w-4 text-green-600" />;
    }
    return <FileText className="h-4 w-4 text-slate-600" />;
  };

  const isExpiringSoon = () => {
    if (!document.expirationDate) return false;
    const expiryDate = new Date(document.expirationDate);
    const now = new Date();
    const daysUntilExpiry = Math.ceil((expiryDate.getTime() - now.getTime()) / (1000 * 3600 * 24));
    return daysUntilExpiry <= 30 && daysUntilExpiry >= 0;
  };

  const isExpired = () => {
    if (!document.expirationDate) return false;
    const expiryDate = new Date(document.expirationDate);
    const now = new Date();
    return expiryDate < now;
  };

  if (compact) {
    return (
      <div className="flex items-center space-x-3">
        <div className="w-8 h-8 bg-slate-100 rounded flex items-center justify-center flex-shrink-0">
          {getFileIcon()}
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium text-slate-900 truncate">{document.title}</p>
          <p className="text-xs text-slate-500">
            {new Date(document.createdAt).toLocaleDateString()} • {formatFileSize(document.fileSize)}
          </p>
        </div>
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={() => downloadMutation.mutate()}
          disabled={downloadMutation.isPending}
        >
          {downloadMutation.isPending ? (
            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary"></div>
          ) : (
            <Download className="h-4 w-4" />
          )}
        </Button>
      </div>
    );
  }

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-slate-100 rounded-lg flex items-center justify-center">
              {getFileIcon()}
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-medium text-slate-900 truncate">{document.title}</h3>
              {document.description && (
                <p className="text-sm text-slate-600 truncate">{document.description}</p>
              )}
            </div>
          </div>
          <div className="flex items-center space-x-2">
            {isExpired() && (
              <Badge variant="destructive" className="text-xs">Expired</Badge>
            )}
            {!isExpired() && isExpiringSoon() && (
              <Badge className="bg-warning text-warning-foreground text-xs">Expiring</Badge>
            )}
            <Badge variant="outline" className="text-xs">
              {document.mimeType.split('/')[1]?.toUpperCase() || 'FILE'}
            </Badge>
          </div>
        </div>

        <div className="space-y-2 text-xs text-slate-500">
          <div className="flex items-center justify-between">
            <span>Size: {formatFileSize(document.fileSize)}</span>
            <span>Uploaded: {new Date(document.createdAt).toLocaleDateString()}</span>
          </div>
          
          {document.expirationDate && (
            <div className="flex items-center space-x-1">
              <Calendar className="h-3 w-3" />
              <span>Expires: {new Date(document.expirationDate).toLocaleDateString()}</span>
            </div>
          )}

          {showEntity && (
            <div className="flex items-center space-x-1">
              <User className="h-3 w-3" />
              <span className="capitalize">{document.entityType}</span>
              {document.entityId && <span>#{document.entityId}</span>}
            </div>
          )}
        </div>

        <div className="flex items-center justify-between mt-4">
          <Button variant="outline" size="sm" className="flex-1 mr-2">
            View Details
          </Button>
          <Button 
            size="sm" 
            onClick={() => downloadMutation.mutate()}
            disabled={downloadMutation.isPending}
            className="flex items-center space-x-1"
          >
            {downloadMutation.isPending ? (
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
            ) : (
              <Download className="h-4 w-4" />
            )}
            <span>Download</span>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
