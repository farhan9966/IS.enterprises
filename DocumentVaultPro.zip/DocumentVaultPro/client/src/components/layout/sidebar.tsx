import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  LayoutDashboard, 
  Car, 
  Users, 
  Folder, 
  Upload, 
  History,
  Settings,
  BarChart3,
  LogOut
} from "lucide-react";

const navigation = [
  {
    title: "Overview",
    items: [
      { name: "Dashboard", href: "/", icon: LayoutDashboard },
      { name: "Analytics", href: "/analytics", icon: BarChart3 },
    ]
  },
  {
    title: "Documents",
    items: [
      { name: "Vehicle Documents", href: "/vehicles", icon: Car },
      { name: "Employee Documents", href: "/employees", icon: Users },
      { name: "Miscellaneous", href: "/miscellaneous", icon: Folder },
    ]
  },
  {
    title: "Management",
    items: [
      { name: "Upload Documents", href: "/upload", icon: Upload },
      { name: "Audit Trail", href: "/audit", icon: History },
      { name: "Settings", href: "/settings", icon: Settings },
    ]
  }
];

export default function Sidebar() {
  const [location] = useLocation();

  return (
    <aside className="w-64 bg-white border-r border-slate-200 flex-shrink-0">
      <nav className="p-6">
        <div className="space-y-6">
          {navigation.map((section) => (
            <div key={section.title}>
              <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-3">
                {section.title}
              </h3>
              <div className="space-y-1">
                {section.items.map((item) => {
                  const isActive = location === item.href;
                  return (
                    <Link key={item.name} href={item.href}>
                      <a
                        className={cn(
                          "flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors",
                          isActive
                            ? "text-primary bg-blue-50"
                            : "text-slate-600 hover:bg-slate-100"
                        )}
                      >
                        <item.icon className="h-5 w-5 mr-3" />
                        {item.name}
                      </a>
                    </Link>
                  );
                })}
              </div>
            </div>
          ))}
          
          {/* Logout Button */}
          <div className="pt-6 border-t border-slate-200">
            <button
              onClick={() => window.location.href = "/api/logout"}
              className="flex items-center w-full px-3 py-2 text-sm font-medium text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
            >
              <LogOut className="h-5 w-5 mr-3" />
              Sign Out
            </button>
          </div>
        </div>
      </nav>
    </aside>
  );
}
