import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Server, Database, Shield, Users, Key, Monitor } from "lucide-react";
import MainLayout from "@/components/layout/main-layout";

export default function Settings() {
  const { user } = useAuth();
  const [serverInfo] = useState({
    hostname: "is-enterprises-prod-01",
    ip: "192.168.1.100",
    port: "5000",
    database: "postgresql://is_enterprises_db",
    uptime: "47 days, 12 hours",
    version: "DocumentTrack Pro v2.1.4",
    lastBackup: "2024-06-24 02:00:00"
  });

  const [clientInfo] = useState({
    browser: navigator.userAgent.includes('Chrome') ? 'Chrome' : 'Other',
    version: navigator.appVersion,
    platform: navigator.platform,
    language: navigator.language,
    cookiesEnabled: navigator.cookieEnabled,
    javaScriptEnabled: true,
    screenResolution: `${screen.width}x${screen.height}`
  });

  return (
    <MainLayout>
      <div className="container mx-auto px-6 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900">System Settings</h1>
          <p className="text-slate-600 mt-2">Manage system configuration and access controls</p>
        </div>

        <Tabs defaultValue="server" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="server">Server Info</TabsTrigger>
            <TabsTrigger value="client">Client Info</TabsTrigger>
            <TabsTrigger value="access">Access Control</TabsTrigger>
            <TabsTrigger value="users">User Management</TabsTrigger>
            <TabsTrigger value="system">System Config</TabsTrigger>
          </TabsList>

          {/* Server Information */}
          <TabsContent value="server" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center space-x-2">
                  <Server className="h-5 w-5 text-blue-600" />
                  <CardTitle>Server Details</CardTitle>
                </div>
                <CardDescription>Current server configuration and status</CardDescription>
              </CardHeader>
              <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <Label className="text-sm font-medium text-slate-700">Hostname</Label>
                    <div className="mt-1 p-3 bg-slate-50 rounded-md border">
                      <code className="text-sm">{serverInfo.hostname}</code>
                    </div>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-slate-700">IP Address</Label>
                    <div className="mt-1 p-3 bg-slate-50 rounded-md border">
                      <code className="text-sm">{serverInfo.ip}</code>
                    </div>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-slate-700">Port</Label>
                    <div className="mt-1 p-3 bg-slate-50 rounded-md border">
                      <code className="text-sm">{serverInfo.port}</code>
                    </div>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-slate-700">Version</Label>
                    <div className="mt-1 p-3 bg-slate-50 rounded-md border">
                      <code className="text-sm">{serverInfo.version}</code>
                    </div>
                  </div>
                </div>
                <div className="space-y-4">
                  <div>
                    <Label className="text-sm font-medium text-slate-700">Database Connection</Label>
                    <div className="mt-1 p-3 bg-slate-50 rounded-md border">
                      <code className="text-xs break-all">{serverInfo.database}</code>
                    </div>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-slate-700">Uptime</Label>
                    <div className="mt-1 p-3 bg-green-50 rounded-md border border-green-200">
                      <Badge variant="outline" className="bg-green-100 text-green-800">
                        {serverInfo.uptime}
                      </Badge>
                    </div>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-slate-700">Last Backup</Label>
                    <div className="mt-1 p-3 bg-slate-50 rounded-md border">
                      <code className="text-sm">{serverInfo.lastBackup}</code>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Client Information */}
          <TabsContent value="client" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center space-x-2">
                  <Monitor className="h-5 w-5 text-green-600" />
                  <CardTitle>Client Information</CardTitle>
                </div>
                <CardDescription>Current browser and client environment details</CardDescription>
              </CardHeader>
              <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <Label className="text-sm font-medium text-slate-700">Browser</Label>
                    <div className="mt-1 p-3 bg-slate-50 rounded-md border">
                      <code className="text-sm">{clientInfo.browser}</code>
                    </div>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-slate-700">Platform</Label>
                    <div className="mt-1 p-3 bg-slate-50 rounded-md border">
                      <code className="text-sm">{clientInfo.platform}</code>
                    </div>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-slate-700">Language</Label>
                    <div className="mt-1 p-3 bg-slate-50 rounded-md border">
                      <code className="text-sm">{clientInfo.language}</code>
                    </div>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-slate-700">Screen Resolution</Label>
                    <div className="mt-1 p-3 bg-slate-50 rounded-md border">
                      <code className="text-sm">{clientInfo.screenResolution}</code>
                    </div>
                  </div>
                </div>
                <div className="space-y-4">
                  <div>
                    <Label className="text-sm font-medium text-slate-700">Cookies Enabled</Label>
                    <div className="mt-1 p-3 bg-slate-50 rounded-md border">
                      <Badge variant={clientInfo.cookiesEnabled ? "default" : "destructive"}>
                        {clientInfo.cookiesEnabled ? "Yes" : "No"}
                      </Badge>
                    </div>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-slate-700">JavaScript Enabled</Label>
                    <div className="mt-1 p-3 bg-slate-50 rounded-md border">
                      <Badge variant={clientInfo.javaScriptEnabled ? "default" : "destructive"}>
                        {clientInfo.javaScriptEnabled ? "Yes" : "No"}
                      </Badge>
                    </div>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-slate-700">User Agent</Label>
                    <div className="mt-1 p-3 bg-slate-50 rounded-md border">
                      <code className="text-xs break-all">{clientInfo.version}</code>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Access Control */}
          <TabsContent value="access" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center space-x-2">
                  <Shield className="h-5 w-5 text-red-600" />
                  <CardTitle>Server Access Credentials</CardTitle>
                </div>
                <CardDescription>System login credentials and access management</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card className="bg-blue-50 border-blue-200">
                    <CardHeader>
                      <CardTitle className="text-lg text-blue-900">Administrator Access</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div>
                        <Label className="text-sm font-medium text-blue-800">Username</Label>
                        <div className="mt-1 p-2 bg-white rounded border">
                          <code className="text-sm">admin@is-enterprises.com</code>
                        </div>
                      </div>
                      <div>
                        <Label className="text-sm font-medium text-blue-800">Password</Label>
                        <div className="mt-1 p-2 bg-white rounded border">
                          <code className="text-sm">ISE_Admin_2024!@#</code>
                        </div>
                      </div>
                      <div>
                        <Label className="text-sm font-medium text-blue-800">Access Level</Label>
                        <Badge variant="default" className="bg-blue-600">Full System Access</Badge>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="bg-green-50 border-green-200">
                    <CardHeader>
                      <CardTitle className="text-lg text-green-900">Manager Access</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div>
                        <Label className="text-sm font-medium text-green-800">Username</Label>
                        <div className="mt-1 p-2 bg-white rounded border">
                          <code className="text-sm">manager@is-enterprises.com</code>
                        </div>
                      </div>
                      <div>
                        <Label className="text-sm font-medium text-green-800">Password</Label>
                        <div className="mt-1 p-2 bg-white rounded border">
                          <code className="text-sm">ISE_Manager_2024</code>
                        </div>
                      </div>
                      <div>
                        <Label className="text-sm font-medium text-green-800">Access Level</Label>
                        <Badge variant="outline" className="bg-green-100 text-green-800">Document Management</Badge>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="bg-amber-50 border-amber-200">
                    <CardHeader>
                      <CardTitle className="text-lg text-amber-900">Staff Access</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div>
                        <Label className="text-sm font-medium text-amber-800">Username</Label>
                        <div className="mt-1 p-2 bg-white rounded border">
                          <code className="text-sm">staff@is-enterprises.com</code>
                        </div>
                      </div>
                      <div>
                        <Label className="text-sm font-medium text-amber-800">Password</Label>
                        <div className="mt-1 p-2 bg-white rounded border">
                          <code className="text-sm">ISE_Staff_2024</code>
                        </div>
                      </div>
                      <div>
                        <Label className="text-sm font-medium text-amber-800">Access Level</Label>
                        <Badge variant="outline" className="bg-amber-100 text-amber-800">View Only</Badge>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="bg-purple-50 border-purple-200">
                    <CardHeader>
                      <CardTitle className="text-lg text-purple-900">Database Access</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div>
                        <Label className="text-sm font-medium text-purple-800">Host</Label>
                        <div className="mt-1 p-2 bg-white rounded border">
                          <code className="text-sm">db.is-enterprises.local</code>
                        </div>
                      </div>
                      <div>
                        <Label className="text-sm font-medium text-purple-800">Username</Label>
                        <div className="mt-1 p-2 bg-white rounded border">
                          <code className="text-sm">is_enterprises_db_admin</code>
                        </div>
                      </div>
                      <div>
                        <Label className="text-sm font-medium text-purple-800">Database</Label>
                        <div className="mt-1 p-2 bg-white rounded border">
                          <code className="text-sm">documenttrack_pro</code>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* User Management */}
          <TabsContent value="users" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center space-x-2">
                  <Users className="h-5 w-5 text-indigo-600" />
                  <CardTitle>Current User Session</CardTitle>
                </div>
                <CardDescription>Your current session information</CardDescription>
              </CardHeader>
              <CardContent>
                {user && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div>
                        <Label className="text-sm font-medium text-slate-700">User ID</Label>
                        <div className="mt-1 p-3 bg-slate-50 rounded-md border">
                          <code className="text-sm">{user.id}</code>
                        </div>
                      </div>
                      <div>
                        <Label className="text-sm font-medium text-slate-700">Email</Label>
                        <div className="mt-1 p-3 bg-slate-50 rounded-md border">
                          <code className="text-sm">{user.email}</code>
                        </div>
                      </div>
                    </div>
                    <div className="space-y-4">
                      <div>
                        <Label className="text-sm font-medium text-slate-700">First Name</Label>
                        <div className="mt-1 p-3 bg-slate-50 rounded-md border">
                          <code className="text-sm">{user.firstName || 'Not provided'}</code>
                        </div>
                      </div>
                      <div>
                        <Label className="text-sm font-medium text-slate-700">Last Name</Label>
                        <div className="mt-1 p-3 bg-slate-50 rounded-md border">
                          <code className="text-sm">{user.lastName || 'Not provided'}</code>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* System Configuration */}
          <TabsContent value="system" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center space-x-2">
                  <Key className="h-5 w-5 text-orange-600" />
                  <CardTitle>System Configuration</CardTitle>
                </div>
                <CardDescription>Application settings and configuration</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="max-file-size">Maximum File Size (MB)</Label>
                      <Input id="max-file-size" type="number" defaultValue="5" className="mt-1" />
                    </div>
                    <div>
                      <Label htmlFor="session-timeout">Session Timeout (minutes)</Label>
                      <Input id="session-timeout" type="number" defaultValue="60" className="mt-1" />
                    </div>
                    <div>
                      <Label htmlFor="backup-frequency">Backup Frequency (hours)</Label>
                      <Input id="backup-frequency" type="number" defaultValue="24" className="mt-1" />
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="allowed-file-types">Allowed File Types</Label>
                      <Input id="allowed-file-types" defaultValue="pdf,jpg,jpeg,png,doc,docx" className="mt-1" />
                    </div>
                    <div>
                      <Label htmlFor="max-documents">Max Documents per Entity</Label>
                      <Input id="max-documents" type="number" defaultValue="100" className="mt-1" />
                    </div>
                    <div>
                      <Label htmlFor="retention-period">Document Retention (days)</Label>
                      <Input id="retention-period" type="number" defaultValue="2555" className="mt-1" />
                    </div>
                  </div>
                </div>
                <Separator />
                <div className="flex space-x-4">
                  <Button>Save Configuration</Button>
                  <Button variant="outline">Reset to Defaults</Button>
                  <Button variant="destructive">Clear Cache</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  );
}