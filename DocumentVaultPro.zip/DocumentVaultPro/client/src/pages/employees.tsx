import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import MainLayout from "@/components/layout/main-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Users, Search, Plus, Download, User } from "lucide-react";

export default function Employees() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: employees } = useQuery({
    queryKey: ["/api/employees"],
    enabled: isAuthenticated,
  });

  const { data: employeeDocuments } = useQuery({
    queryKey: ["/api/documents?entityType=employee"],
    enabled: isAuthenticated,
  });

  if (isLoading || !isAuthenticated) {
    return null;
  }

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">Employee Documents</h1>
            <p className="text-slate-600">Manage employee records, certifications, and HR documents</p>
          </div>
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            Add Employee
          </Button>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 h-4 w-4" />
          <Input 
            placeholder="Search employees..." 
            className="pl-10"
          />
        </div>

        {/* Two Column Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column: Employee Categories and List */}
          <div className="lg:col-span-2 space-y-6">
            {/* Employee Document Categories */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="cursor-pointer hover:bg-slate-50">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                      <User className="h-6 w-6 text-primary" />
                    </div>
                    <Badge>0 docs</Badge>
                  </div>
                  <h3 className="font-semibold text-slate-900 mb-2">Personal Information</h3>
                  <p className="text-sm text-slate-600">IDs, contact info, and personal details</p>
                </CardContent>
              </Card>

              <Card className="cursor-pointer hover:bg-slate-50">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                      <Users className="h-6 w-6 text-accent" />
                    </div>
                    <Badge variant="secondary">0 docs</Badge>
                  </div>
                  <h3 className="font-semibold text-slate-900 mb-2">Certifications</h3>
                  <p className="text-sm text-slate-600">Professional licenses and certifications</p>
                </CardContent>
              </Card>

              <Card className="cursor-pointer hover:bg-slate-50">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center">
                      <Users className="h-6 w-6 text-secondary" />
                    </div>
                    <Badge variant="secondary">0 docs</Badge>
                  </div>
                  <h3 className="font-semibold text-slate-900 mb-2">HR Documents</h3>
                  <p className="text-sm text-slate-600">Contracts, evaluations, and HR records</p>
                </CardContent>
              </Card>
            </div>

            {/* Employee List */}
            <Card>
              <CardHeader>
                <CardTitle>All Employees</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {employees?.length ? (
                    employees.map((employee: any) => (
                      <div key={employee.id} className="flex items-center justify-between p-4 border border-slate-200 rounded-lg hover:bg-slate-50">
                        <div className="flex items-center space-x-4">
                          <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                            <User className="h-5 w-5 text-primary" />
                          </div>
                          <div>
                            <h3 className="font-medium text-slate-900">
                              {employee.firstName} {employee.lastName}
                            </h3>
                            <p className="text-sm text-slate-500">
                              {employee.position} - {employee.department}
                            </p>
                            {employee.employeeId && (
                              <p className="text-xs text-slate-400">ID: {employee.employeeId}</p>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge variant={employee.status === 'active' ? 'default' : 'secondary'}>
                            {employee.status}
                          </Badge>
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => window.location.href = `/employees/${employee.id}`}
                          >
                            View Details
                          </Button>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-8">
                      <Users className="h-12 w-12 text-slate-400 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-slate-900 mb-2">No employees found</h3>
                      <p className="text-slate-600 mb-4">Add your first employee to start managing documents</p>
                      <Button>
                        <Plus className="h-4 w-4 mr-2" />
                        Add Employee
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Column: Document Attachments */}
          <div className="space-y-6">
            {/* Recent Employee Documents */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Documents</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {employeeDocuments?.slice(0, 5).map((doc: any) => (
                    <div key={doc.id} className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-slate-100 rounded flex items-center justify-center flex-shrink-0">
                        <Download className="h-4 w-4 text-slate-600" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-slate-900 truncate">{doc.title}</p>
                        <p className="text-xs text-slate-500">
                          {new Date(doc.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                      <Button variant="ghost" size="sm">
                        <Download className="h-4 w-4" />
                      </Button>
                    </div>
                  )) || (
                    <p className="text-sm text-slate-500">No documents uploaded yet</p>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button className="w-full justify-start">
                  <Plus className="h-4 w-4 mr-2" />
                  Upload Document
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Download className="h-4 w-4 mr-2" />
                  Bulk Download
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Search className="h-4 w-4 mr-2" />
                  Advanced Search
                </Button>
              </CardContent>
            </Card>

            {/* Employee Statistics */}
            <Card>
              <CardHeader>
                <CardTitle>Employee Stats</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-600">Active Employees</span>
                    <span className="font-medium">{employees?.filter((e: any) => e.status === 'active').length || 0}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-600">Total Documents</span>
                    <span className="font-medium">{employeeDocuments?.length || 0}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-600">Departments</span>
                    <span className="font-medium">
                      {new Set(employees?.map((e: any) => e.department).filter(Boolean)).size || 0}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
