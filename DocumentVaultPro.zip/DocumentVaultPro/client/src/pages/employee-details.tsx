import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  User, 
  Mail, 
  Phone, 
  Calendar, 
  FileText, 
  Download, 
  Upload,
  Building,
  Clock,
  MapPin
} from "lucide-react";
import MainLayout from "@/components/layout/main-layout";
import DocumentCard from "@/components/documents/document-card";

export default function EmployeeDetails() {
  const { id } = useParams();
  
  const { data: employee, isLoading: employeeLoading } = useQuery({
    queryKey: ["/api/employees", id],
  });

  const { data: documents, isLoading: documentsLoading } = useQuery({
    queryKey: ["/api/documents", "employee", id],
  });

  if (employeeLoading) {
    return (
      <MainLayout>
        <div className="container mx-auto px-6 py-8">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-slate-200 rounded w-1/3"></div>
            <div className="h-48 bg-slate-200 rounded"></div>
          </div>
        </div>
      </MainLayout>
    );
  }

  if (!employee) {
    return (
      <MainLayout>
        <div className="container mx-auto px-6 py-8">
          <Card>
            <CardContent className="text-center py-12">
              <User className="h-12 w-12 text-slate-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-slate-900 mb-2">Employee Not Found</h3>
              <p className="text-slate-600">The requested employee could not be found.</p>
            </CardContent>
          </Card>
        </div>
      </MainLayout>
    );
  }

  const employeeDocuments = documents?.filter((doc: any) => 
    doc.entityType === 'employee' && doc.entityId === parseInt(id!)
  ) || [];

  return (
    <MainLayout>
      <div className="container mx-auto px-6 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-slate-900">
                {employee.firstName} {employee.lastName}
              </h1>
              <p className="text-slate-600 mt-1">{employee.position} • {employee.department}</p>
            </div>
            <div className="flex space-x-3">
              <Button variant="outline">
                <Upload className="h-4 w-4 mr-2" />
                Upload Document
              </Button>
              <Button>
                <Mail className="h-4 w-4 mr-2" />
                Send Email
              </Button>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column: Employee Information */}
          <div className="lg:col-span-1 space-y-6">
            {/* Basic Information */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <User className="h-5 w-5" />
                  <span>Employee Information</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="text-center">
                  <div className="w-24 h-24 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto mb-4">
                    {employee.firstName?.[0]}{employee.lastName?.[0]}
                  </div>
                  <h3 className="font-semibold text-lg">{employee.firstName} {employee.lastName}</h3>
                  <p className="text-slate-600">{employee.position}</p>
                  <Badge variant="outline" className="mt-2">
                    {employee.status === 'active' ? 'Active Employee' : 'Inactive'}
                  </Badge>
                </div>

                <Separator />

                <div className="space-y-4">
                  <div className="flex items-center space-x-3">
                    <Mail className="h-4 w-4 text-slate-500" />
                    <div>
                      <p className="text-sm font-medium text-slate-700">Email</p>
                      <p className="text-sm text-slate-600">{employee.email}</p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-3">
                    <Phone className="h-4 w-4 text-slate-500" />
                    <div>
                      <p className="text-sm font-medium text-slate-700">Phone</p>
                      <p className="text-sm text-slate-600">{employee.phone || 'Not provided'}</p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-3">
                    <Building className="h-4 w-4 text-slate-500" />
                    <div>
                      <p className="text-sm font-medium text-slate-700">Department</p>
                      <p className="text-sm text-slate-600">{employee.department}</p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-3">
                    <Calendar className="h-4 w-4 text-slate-500" />
                    <div>
                      <p className="text-sm font-medium text-slate-700">Hire Date</p>
                      <p className="text-sm text-slate-600">
                        {employee.hireDate ? new Date(employee.hireDate).toLocaleDateString() : 'Not specified'}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-3">
                    <Clock className="h-4 w-4 text-slate-500" />
                    <div>
                      <p className="text-sm font-medium text-slate-700">Employee Since</p>
                      <p className="text-sm text-slate-600">
                        {employee.hireDate ? 
                          `${Math.floor((new Date().getTime() - new Date(employee.hireDate).getTime()) / (1000 * 60 * 60 * 24 * 365))} years` : 
                          'Unknown'
                        }
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Stats */}
            <Card>
              <CardHeader>
                <CardTitle>Document Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold text-blue-600">{employeeDocuments.length}</div>
                    <div className="text-sm text-slate-600">Total Documents</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-amber-600">
                      {employeeDocuments.filter((doc: any) => doc.expirationDate && new Date(doc.expirationDate) < new Date()).length}
                    </div>
                    <div className="text-sm text-slate-600">Expiring Soon</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Column: Documents and Details */}
          <div className="lg:col-span-2">
            <Tabs defaultValue="documents" className="space-y-6">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="documents">Documents</TabsTrigger>
                <TabsTrigger value="activity">Activity Log</TabsTrigger>
                <TabsTrigger value="details">Additional Details</TabsTrigger>
              </TabsList>

              {/* Documents Tab */}
              <TabsContent value="documents" className="space-y-6">
                <Card>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="flex items-center space-x-2">
                          <FileText className="h-5 w-5" />
                          <span>Employee Documents</span>
                        </CardTitle>
                        <CardDescription>
                          Documents associated with {employee.firstName} {employee.lastName}
                        </CardDescription>
                      </div>
                      <Button variant="outline" size="sm">
                        <Upload className="h-4 w-4 mr-2" />
                        Add Document
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    {documentsLoading ? (
                      <div className="space-y-4">
                        {[...Array(3)].map((_, i) => (
                          <div key={i} className="animate-pulse">
                            <div className="h-20 bg-slate-200 rounded"></div>
                          </div>
                        ))}
                      </div>
                    ) : employeeDocuments.length > 0 ? (
                      <div className="space-y-4">
                        {employeeDocuments.map((document: any) => (
                          <DocumentCard 
                            key={document.id} 
                            document={document} 
                            showEntity={false}
                            compact={true}
                          />
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-12">
                        <FileText className="h-12 w-12 text-slate-400 mx-auto mb-4" />
                        <h3 className="text-lg font-medium text-slate-900 mb-2">No Documents Found</h3>
                        <p className="text-slate-600 mb-4">
                          No documents have been uploaded for this employee yet.
                        </p>
                        <Button>
                          <Upload className="h-4 w-4 mr-2" />
                          Upload First Document
                        </Button>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Activity Log Tab */}
              <TabsContent value="activity" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Recent Activity</CardTitle>
                    <CardDescription>Recent actions and document access history</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {employeeDocuments.slice(0, 5).map((doc: any, index: number) => (
                        <div key={doc.id} className="flex items-center space-x-4 p-3 bg-slate-50 rounded-lg">
                          <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                            <FileText className="h-4 w-4 text-blue-600" />
                          </div>
                          <div className="flex-1">
                            <p className="text-sm font-medium text-slate-900">
                              Document "{doc.title}" was uploaded
                            </p>
                            <p className="text-xs text-slate-600">
                              {new Date(doc.createdAt).toLocaleDateString()} at {new Date(doc.createdAt).toLocaleTimeString()}
                            </p>
                          </div>
                        </div>
                      ))}
                      {employeeDocuments.length === 0 && (
                        <div className="text-center py-8">
                          <p className="text-slate-600">No recent activity found.</p>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Additional Details Tab */}
              <TabsContent value="details" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Additional Information</CardTitle>
                    <CardDescription>Extended employee details and metadata</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <h4 className="font-medium text-slate-900 mb-3">Employment Details</h4>
                        <div className="space-y-3">
                          <div>
                            <label className="text-sm font-medium text-slate-700">Employee ID</label>
                            <p className="text-sm text-slate-600">EMP-{employee.id.toString().padStart(4, '0')}</p>
                          </div>
                          <div>
                            <label className="text-sm font-medium text-slate-700">Status</label>
                            <p className="text-sm text-slate-600 capitalize">{employee.status}</p>
                          </div>
                          <div>
                            <label className="text-sm font-medium text-slate-700">Record Created</label>
                            <p className="text-sm text-slate-600">
                              {new Date(employee.createdAt).toLocaleDateString()}
                            </p>
                          </div>
                          <div>
                            <label className="text-sm font-medium text-slate-700">Last Updated</label>
                            <p className="text-sm text-slate-600">
                              {new Date(employee.updatedAt).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                      </div>
                      <div>
                        <h4 className="font-medium text-slate-900 mb-3">Document Statistics</h4>
                        <div className="space-y-3">
                          <div>
                            <label className="text-sm font-medium text-slate-700">Total Documents</label>
                            <p className="text-sm text-slate-600">{employeeDocuments.length}</p>
                          </div>
                          <div>
                            <label className="text-sm font-medium text-slate-700">Documents with Expiration</label>
                            <p className="text-sm text-slate-600">
                              {employeeDocuments.filter((doc: any) => doc.expirationDate).length}
                            </p>
                          </div>
                          <div>
                            <label className="text-sm font-medium text-slate-700">Expired Documents</label>
                            <p className="text-sm text-red-600">
                              {employeeDocuments.filter((doc: any) => 
                                doc.expirationDate && new Date(doc.expirationDate) < new Date()
                              ).length}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}