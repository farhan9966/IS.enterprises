import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileText, Shield, Users, Car, Upload, Search } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <FileText className="h-8 w-8 text-primary" />
              <h1 className="text-2xl font-bold text-slate-900">DocumentTrack Pro - IS Enterprises</h1>
            </div>
            <Button onClick={() => window.location.href = "/api/login"}>
              Sign In
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <main className="container mx-auto px-6 py-12">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-slate-900 mb-4">
            IS Enterprises Document Management System
          </h2>
          <p className="text-xl text-slate-600 mb-8 max-w-3xl mx-auto">
            IS Enterprises' comprehensive solution for securely managing vehicle, employee, and miscellaneous documents 
            with role-based access control, expiration tracking, and comprehensive audit trails.
          </p>
          <Button 
            size="lg" 
            className="text-lg px-8 py-3"
            onClick={() => window.location.href = "/api/login"}
          >
            Get Started
          </Button>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          <Card>
            <CardHeader>
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                <Car className="h-6 w-6 text-primary" />
              </div>
              <CardTitle>Vehicle Documents</CardTitle>
              <CardDescription>
                Manage registrations, insurance policies, maintenance records, and permits
              </CardDescription>
            </CardHeader>
          </Card>

          <Card>
            <CardHeader>
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                <Users className="h-6 w-6 text-primary" />
              </div>
              <CardTitle>Employee Records</CardTitle>
              <CardDescription>
                Store personal information, certifications, licenses, and HR documents
              </CardDescription>
            </CardHeader>
          </Card>

          <Card>
            <CardHeader>
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                <Shield className="h-6 w-6 text-primary" />
              </div>
              <CardTitle>Role-Based Access</CardTitle>
              <CardDescription>
                Secure access control with admin, manager, and staff permission levels
              </CardDescription>
            </CardHeader>
          </Card>

          <Card>
            <CardHeader>
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                <Upload className="h-6 w-6 text-primary" />
              </div>
              <CardTitle>Easy Upload</CardTitle>
              <CardDescription>
                Drag-and-drop interface with file validation and size limits
              </CardDescription>
            </CardHeader>
          </Card>

          <Card>
            <CardHeader>
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                <Search className="h-6 w-6 text-primary" />
              </div>
              <CardTitle>Advanced Search</CardTitle>
              <CardDescription>
                Quickly find documents across all categories and entities
              </CardDescription>
            </CardHeader>
          </Card>

          <Card>
            <CardHeader>
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                <FileText className="h-6 w-6 text-primary" />
              </div>
              <CardTitle>Audit Trail</CardTitle>
              <CardDescription>
                Complete tracking of document access, downloads, and modifications
              </CardDescription>
            </CardHeader>
          </Card>
        </div>

        {/* CTA Section */}
        <div className="text-center bg-white rounded-lg border border-slate-200 p-12">
          <h3 className="text-2xl font-bold text-slate-900 mb-4">
            Ready to streamline your document management?
          </h3>
          <p className="text-slate-600 mb-8">
            Sign in to access your secure document management dashboard.
          </p>
          <Button 
            size="lg"
            onClick={() => window.location.href = "/api/login"}
          >
            Access Dashboard
          </Button>
        </div>
      </main>
    </div>
  );
}
