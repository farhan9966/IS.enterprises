import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import MainLayout from "@/components/layout/main-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import UploadZone from "@/components/documents/upload-zone";
import ExpiringDocuments from "@/components/documents/expiring-documents";
import RecentDownloads from "@/components/documents/recent-downloads";
import { FileText, AlertTriangle, Car, Users, ArrowUp, TrendingUp } from "lucide-react";

export default function Dashboard() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/dashboard/stats"],
    enabled: isAuthenticated,
  });

  const { data: recentDocuments } = useQuery({
    queryKey: ["/api/dashboard/recent-documents"],
    enabled: isAuthenticated,
  });

  const { data: vehicleDocuments } = useQuery({
    queryKey: ["/api/documents", "vehicle"],
    enabled: isAuthenticated,
  });

  if (isLoading || !isAuthenticated) {
    return null;
  }

  // Group vehicle documents by category for display
  const vehicleDocsByCategory = vehicleDocuments?.reduce((acc: any, doc: any) => {
    const category = doc.categoryId;
    if (!acc[category]) acc[category] = [];
    acc[category].push(doc);
    return acc;
  }, {}) || {};

  return (
    <MainLayout>
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600">Total Documents</p>
                <p className="text-3xl font-bold text-slate-900">
                  {statsLoading ? "..." : stats?.totalDocuments || 0}
                </p>
              </div>
              <FileText className="h-8 w-8 text-primary" />
            </div>
            <p className="text-sm text-accent mt-2 flex items-center">
              <ArrowUp className="h-4 w-4 mr-1" />
              +12% from last month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600">Expiring Soon</p>
                <p className="text-3xl font-bold text-warning">
                  {statsLoading ? "..." : stats?.expiringSoon || 0}
                </p>
              </div>
              <AlertTriangle className="h-8 w-8 text-warning" />
            </div>
            <p className="text-sm text-slate-500 mt-2">Next 30 days</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600">Active Vehicles</p>
                <p className="text-3xl font-bold text-slate-900">
                  {statsLoading ? "..." : stats?.activeVehicles || 0}
                </p>
              </div>
              <Car className="h-8 w-8 text-accent" />
            </div>
            <p className="text-sm text-slate-500 mt-2">All tracked vehicles</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600">Employees</p>
                <p className="text-3xl font-bold text-slate-900">
                  {statsLoading ? "..." : stats?.activeEmployees || 0}
                </p>
              </div>
              <Users className="h-8 w-8 text-primary" />
            </div>
            <p className="text-sm text-slate-500 mt-2">Active staff members</p>
          </CardContent>
        </Card>
      </div>

      {/* Two Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Document Details */}
        <div className="lg:col-span-2 space-y-6">
          {/* Recent Activity */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Recent Activity</CardTitle>
                <Button variant="link" size="sm">View All</Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentDocuments?.slice(0, 5).map((doc: any) => (
                  <div key={doc.id} className="flex items-start space-x-3">
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <FileText className="h-4 w-4 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-slate-900">
                        <span className="font-medium">{doc.title}</span> was uploaded
                      </p>
                      <p className="text-xs text-slate-500">
                        {new Date(doc.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                )) || (
                  <p className="text-sm text-slate-500">No recent activity</p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Vehicle Documents Preview */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Vehicle Documents</CardTitle>
                <Button variant="link" size="sm">Manage All</Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 border border-slate-200 rounded-lg hover:bg-slate-50 cursor-pointer">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-medium text-slate-900">Registration Documents</h3>
                    <Badge variant="secondary">
                      {vehicleDocsByCategory[1]?.length || 0} docs
                    </Badge>
                  </div>
                  <p className="text-sm text-slate-600">Vehicle registrations, titles, and ownership documents</p>
                </div>

                <div className="p-4 border border-slate-200 rounded-lg hover:bg-slate-50 cursor-pointer">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-medium text-slate-900">Insurance Policies</h3>
                    <Badge className="bg-warning text-warning-foreground">
                      {vehicleDocsByCategory[2]?.length || 0} docs
                    </Badge>
                  </div>
                  <p className="text-sm text-slate-600">Insurance certificates and policy documents</p>
                </div>

                <div className="p-4 border border-slate-200 rounded-lg hover:bg-slate-50 cursor-pointer">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-medium text-slate-900">Maintenance Records</h3>
                    <Badge>
                      {vehicleDocsByCategory[3]?.length || 0} docs
                    </Badge>
                  </div>
                  <p className="text-sm text-slate-600">Service records, inspections, and repairs</p>
                </div>

                <div className="p-4 border border-slate-200 rounded-lg hover:bg-slate-50 cursor-pointer">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-medium text-slate-900">Permits & Licenses</h3>
                    <Badge variant="secondary">
                      {vehicleDocsByCategory[4]?.length || 0} docs
                    </Badge>
                  </div>
                  <p className="text-sm text-slate-600">Operating permits and special licenses</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right Column: Document Attachments & Quick Actions */}
        <div className="space-y-6">
          {/* Quick Upload */}
          <Card>
            <CardHeader>
              <CardTitle>Quick Upload</CardTitle>
            </CardHeader>
            <CardContent>
              <UploadZone />
            </CardContent>
          </Card>

          {/* Expiring Documents */}
          <ExpiringDocuments />

          {/* Recent Downloads */}
          <RecentDownloads />
        </div>
      </div>

      {/* Employee Documents Section */}
      <div className="mt-8">
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Employee Documents</CardTitle>
              <Button variant="link" size="sm">Manage All</Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 border border-slate-200 rounded-lg hover:bg-slate-50 cursor-pointer">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-medium text-slate-900">Personal Information</h3>
                  <Badge>0 docs</Badge>
                </div>
                <p className="text-sm text-slate-600">IDs, contact info, and personal details</p>
              </div>

              <div className="p-4 border border-slate-200 rounded-lg hover:bg-slate-50 cursor-pointer">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-medium text-slate-900">Certifications</h3>
                  <Badge variant="secondary">0 docs</Badge>
                </div>
                <p className="text-sm text-slate-600">Professional licenses and certifications</p>
              </div>

              <div className="p-4 border border-slate-200 rounded-lg hover:bg-slate-50 cursor-pointer">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-medium text-slate-900">HR Documents</h3>
                  <Badge variant="secondary">0 docs</Badge>
                </div>
                <p className="text-sm text-slate-600">Contracts, evaluations, and HR records</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}
