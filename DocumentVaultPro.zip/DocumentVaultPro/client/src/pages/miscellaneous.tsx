import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import MainLayout from "@/components/layout/main-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Folder, Search, Plus, Download, FileText } from "lucide-react";

export default function Miscellaneous() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: miscDocuments } = useQuery({
    queryKey: ["/api/documents?entityType=miscellaneous"],
    enabled: isAuthenticated,
  });

  if (isLoading || !isAuthenticated) {
    return null;
  }

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">Miscellaneous Documents</h1>
            <p className="text-slate-600">Manage general documents, policies, and other important files</p>
          </div>
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            Upload Document
          </Button>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 h-4 w-4" />
          <Input 
            placeholder="Search miscellaneous documents..." 
            className="pl-10"
          />
        </div>

        {/* Two Column Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column: Document Categories */}
          <div className="lg:col-span-2 space-y-6">
            {/* Document Categories */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <Card className="cursor-pointer hover:bg-slate-50">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                      <FileText className="h-6 w-6 text-primary" />
                    </div>
                    <Badge>0 docs</Badge>
                  </div>
                  <h3 className="font-semibold text-slate-900 mb-2">Company Policies</h3>
                  <p className="text-sm text-slate-600">Internal policies, procedures, and guidelines</p>
                </CardContent>
              </Card>

              <Card className="cursor-pointer hover:bg-slate-50">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                      <Folder className="h-6 w-6 text-accent" />
                    </div>
                    <Badge variant="secondary">0 docs</Badge>
                  </div>
                  <h3 className="font-semibold text-slate-900 mb-2">Legal Documents</h3>
                  <p className="text-sm text-slate-600">Contracts, agreements, and legal forms</p>
                </CardContent>
              </Card>

              <Card className="cursor-pointer hover:bg-slate-50">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                      <FileText className="h-6 w-6 text-warning" />
                    </div>
                    <Badge className="bg-warning text-warning-foreground">0 docs</Badge>
                  </div>
                  <h3 className="font-semibold text-slate-900 mb-2">Training Materials</h3>
                  <p className="text-sm text-slate-600">Training guides, manuals, and resources</p>
                </CardContent>
              </Card>

              <Card className="cursor-pointer hover:bg-slate-50">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                      <Folder className="h-6 w-6 text-purple-600" />
                    </div>
                    <Badge variant="secondary">0 docs</Badge>
                  </div>
                  <h3 className="font-semibold text-slate-900 mb-2">Safety Documents</h3>
                  <p className="text-sm text-slate-600">Safety protocols, MSDS, and compliance docs</p>
                </CardContent>
              </Card>

              <Card className="cursor-pointer hover:bg-slate-50">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center">
                      <FileText className="h-6 w-6 text-indigo-600" />
                    </div>
                    <Badge variant="secondary">0 docs</Badge>
                  </div>
                  <h3 className="font-semibold text-slate-900 mb-2">Financial Records</h3>
                  <p className="text-sm text-slate-600">Invoices, receipts, and financial documents</p>
                </CardContent>
              </Card>

              <Card className="cursor-pointer hover:bg-slate-50">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center">
                      <Folder className="h-6 w-6 text-secondary" />
                    </div>
                    <Badge variant="secondary">0 docs</Badge>
                  </div>
                  <h3 className="font-semibold text-slate-900 mb-2">General Files</h3>
                  <p className="text-sm text-slate-600">Other documents and miscellaneous files</p>
                </CardContent>
              </Card>
            </div>

            {/* Document List */}
            <Card>
              <CardHeader>
                <CardTitle>All Miscellaneous Documents</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {miscDocuments?.length ? (
                    miscDocuments.map((doc: any) => (
                      <div key={doc.id} className="flex items-center justify-between p-4 border border-slate-200 rounded-lg hover:bg-slate-50">
                        <div className="flex items-center space-x-4">
                          <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                            <FileText className="h-5 w-5 text-primary" />
                          </div>
                          <div>
                            <h3 className="font-medium text-slate-900">{doc.title}</h3>
                            <p className="text-sm text-slate-500">{doc.description}</p>
                            <p className="text-xs text-slate-400">
                              Uploaded {new Date(doc.createdAt).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge variant="outline">
                            {doc.mimeType?.split('/')[1]?.toUpperCase() || 'FILE'}
                          </Badge>
                          <Button variant="outline" size="sm">
                            <Download className="h-4 w-4 mr-2" />
                            Download
                          </Button>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-8">
                      <Folder className="h-12 w-12 text-slate-400 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-slate-900 mb-2">No documents found</h3>
                      <p className="text-slate-600 mb-4">Upload your first miscellaneous document to get started</p>
                      <Button>
                        <Plus className="h-4 w-4 mr-2" />
                        Upload Document
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Column: Document Attachments and Tools */}
          <div className="space-y-6">
            {/* Recent Documents */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Uploads</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {miscDocuments?.slice(0, 5).map((doc: any) => (
                    <div key={doc.id} className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-slate-100 rounded flex items-center justify-center flex-shrink-0">
                        <FileText className="h-4 w-4 text-slate-600" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-slate-900 truncate">{doc.title}</p>
                        <p className="text-xs text-slate-500">
                          {new Date(doc.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                      <Button variant="ghost" size="sm">
                        <Download className="h-4 w-4" />
                      </Button>
                    </div>
                  )) || (
                    <p className="text-sm text-slate-500">No documents uploaded yet</p>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button className="w-full justify-start">
                  <Plus className="h-4 w-4 mr-2" />
                  Upload Document
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Download className="h-4 w-4 mr-2" />
                  Bulk Download
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Search className="h-4 w-4 mr-2" />
                  Advanced Search
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Folder className="h-4 w-4 mr-2" />
                  Create Category
                </Button>
              </CardContent>
            </Card>

            {/* Document Statistics */}
            <Card>
              <CardHeader>
                <CardTitle>Document Stats</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-600">Total Documents</span>
                    <span className="font-medium">{miscDocuments?.length || 0}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-600">Categories</span>
                    <span className="font-medium">6</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-600">Storage Used</span>
                    <span className="font-medium">
                      {miscDocuments?.reduce((acc: number, doc: any) => acc + (doc.fileSize || 0), 0) 
                        ? `${Math.round(miscDocuments.reduce((acc: number, doc: any) => acc + (doc.fileSize || 0), 0) / 1024 / 1024)} MB`
                        : '0 MB'}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
